# CA Creative - Site Oficial de Alta Conversão

Portfólio e site de vendas profissional para a **CA Creative** desenvolvido em React + TypeScript + Tailwind CSS (Vite).

## 🚀 Como Hospedar no Netlify

### Opção 1: Arrastar e Soltar a pasta construída (Método Mais Fácil)
1. Extraia o arquivo `.zip` no seu computador.
2. No terminal dentro da pasta extraída, execute:
   ```bash
   npm install
   npm run build
   ```
3. Acesse [Netlify Drop](https://app.netlify.com/drop).
4. Arraste e solte a pasta `dist` gerada.
5. Pronto! O site estará online imediatamente com certificado SSL e domínio gratuito.

### Opção 2: Conectar ao GitHub no Netlify
1. Crie um repositório no seu GitHub e envie os arquivos deste projeto.
2. No Netlify, clique em **Add new site** > **Import an existing project** > **GitHub**.
3. Selecione o repositório.
4. O Netlify detectará automaticamente:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
5. Clique em **Deploy site**.

---

## 💜 Como Usar no Lovable

1. No Lovable, inicie um novo projeto ou clique em **Import from GitHub** / **Upload Codebase**.
2. Faça upload dos arquivos do projeto contidos neste `.zip` (mantendo a estrutura de pastas `src/`, `package.json`, `index.html`, etc.).
3. O Lovable reconhecerá a stack React + Vite + Tailwind CSS imediatamente.

---

## 💻 Como Rodar Localmente no seu Computador

1. Tenha o [Node.js](https://nodejs.org/) instalado (versão 18 ou superior).
2. Abra a pasta do projeto no terminal ou VS Code.
3. Instale as dependências:
   ```bash
   npm install
   ```
4. Inicie o servidor local:
   ```bash
   npm run dev
   ```
5. Abra `http://localhost:3000` no seu navegador.
