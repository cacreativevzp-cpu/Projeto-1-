/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Differentials } from './components/Differentials';
import { About } from './components/About';
import { Services } from './components/Services';
import { Portfolio } from './components/Portfolio';
import { Testimonials } from './components/Testimonials';
import { Faq } from './components/Faq';
import { ContactSection } from './components/ContactSection';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { Footer } from './components/Footer';
import { DownloadModal } from './components/DownloadModal';

export default function App() {
  return (
    <div className="min-h-screen bg-[#09090b] text-[#f4f4f5] flex flex-col font-sans selection:bg-purple-500/30 selection:text-purple-200">
      {/* Fixed Navigation Bar */}
      <Navbar />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* 1. Hero Section Impactante */}
        <Hero />

        {/* 2. Diferenciais Competitivos (Entrega no mesmo dia, atendimento humanizado, faturamento) */}
        <Differentials />

        {/* 3. Sobre a CA Creative & Quem Somos */}
        <About />

        {/* 4. Serviços & Simulador Interativo de Orçamento */}
        <Services />

        {/* 5. Portfólio & Casos de Sucesso Reais */}
        <Portfolio />

        {/* 6. Prova Social & Depoimentos */}
        <Testimonials />

        {/* 7. Perguntas Frequentes (FAQ) */}
        <Faq />

        {/* 8. Formulário de Contato Direto & WhatsApp */}
        <ContactSection />
      </main>

      {/* WhatsApp Flutuante com status online */}
      <FloatingWhatsApp />

      {/* Modal e Botão Flutuante de Download do ZIP para Netlify & Lovable */}
      <DownloadModal />

      {/* Rodapé Completo */}
      <Footer />
    </div>
  );
}
