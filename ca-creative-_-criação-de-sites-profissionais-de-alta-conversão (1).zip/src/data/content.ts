/**
 * Centralized content & data for CA Creative
 * WhatsApp: 554799894731
 * Instagram: @cacreativeoficial
 */

export const CONTACT_INFO = {
  brandName: 'CA Creative',
  tagline: 'Seu negócio merece ser visto. Nós fazemos o mundo encontrar você!',
  whatsappNumber: '554799894731',
  whatsappDisplay: '(47) 99894-731',
  instagramHandle: '@cacreativeoficial',
  instagramUrl: 'https://instagram.com/cacreativeoficial',
  email: 'contato@cacreative.com.br',
  region: 'Brasil (Atendimento Nacional)',
};

export function buildWhatsAppLink(message: string): string {
  const encoded = encodeURIComponent(message.trim());
  return `https://wa.me/${CONTACT_INFO.whatsappNumber}?text=${encoded}`;
}

export const DIFFERENTIALS = [
  {
    id: 'express-delivery',
    title: 'Entrega no Mesmo Dia',
    subtitle: 'Velocidade Imbatível',
    description:
      'Seu negócio não pode esperar semanas para começar a vender. Com nossa metodologia ágil, entregamos sua Landing Page profissional e pronta no mesmo dia.',
    badge: '⚡ Express 24h',
  },
  {
    id: 'human-care',
    title: 'Atendimento Humanizado',
    subtitle: 'Contato Direto',
    description:
      'Sem robôs, sem tickets e sem jargões complicados. Você conversa direto no WhatsApp com os especialistas responsáveis pela sua criação.',
    badge: '🤝 100% Pessoal',
  },
  {
    id: 'conversion-focus',
    title: 'Foco no Seu Faturamento',
    subtitle: 'Design que Vende',
    description:
      'Não criamos apenas sites bonitos. Estruturamos copywriting persuasivo, gatilhos mentais e chamadas de ação para transformar visitantes em dinheiro no caixa.',
    badge: '📈 Alta Conversão',
  },
  {
    id: 'mobile-first',
    title: 'Mobile-First & Ultrarrápido',
    subtitle: 'Zero Lentidão',
    description:
      'Mais de 85% dos seus clientes acessam pelo celular. Nossos sites carregam em menos de 1,5s no 4G/5G, garantindo que você nunca perca uma venda.',
    badge: '📱 100% Responsivo',
  },
  {
    id: 'premium-aesthetic',
    title: 'Design Preto & Dourado Exclusivo',
    subtitle: 'Autoridade Imediata',
    description:
      'Visual moderno minimalista com hierarquia refinada. Seu estabelecimento transmite luxo, credibilidade e solidez logo no primeiro clique.',
    badge: '💎 Padrão Premium',
  },
  {
    id: 'turnkey-ready',
    title: 'Site 100% Pronto para Usar',
    subtitle: 'Chave na Mão',
    description:
      'Entregamos tudo configurado: domínio, certificado de segurança SSL, botão de WhatsApp direto e integração com seu Instagram.',
    badge: '🛡️ Garantia Total',
  },
];

export interface ServiceItem {
  id: string;
  title: string;
  tagline: string;
  description: string;
  deliveryTime: string;
  idealFor: string;
  features: string[];
  recommended?: boolean;
}

export const SERVICES: ServiceItem[] = [
  {
    id: 'landing-page',
    title: 'Landing Page de Alta Conversão',
    tagline: 'Ideal para tráfego pago & captação imediata',
    description:
      'Página única focada em uma única ação: fazer o visitante chamar no seu WhatsApp ou comprar o seu produto. Copywriting persuasivo de ponta a ponta.',
    deliveryTime: 'Entrega no mesmo dia',
    idealFor: 'Anúncios no Meta/Google, lançamentos, produtos e serviços locais',
    features: [
      'Copywriting persuasivo e de vendas',
      'Botões de WhatsApp com rastreio de clique',
      'Velocidade ultrarrápida (Nota A no PageSpeed)',
      'Otimizada para celulares e desktop',
      'Design exclusivo no padrão de luxo',
    ],
    recommended: true,
  },
  {
    id: 'site-institucional',
    title: 'Site Institucional Premium',
    tagline: 'A máxima autoridade para o seu negócio',
    description:
      'Apresente sua empresa, clínica, escritório ou comércio com a seriedade e o requinte que os grandes contratos exigem. Estrutura completa de páginas.',
    deliveryTime: '24h a 48h úteis',
    idealFor: 'Clínicas médicas, escritórios de advocacia, consultorias e empresas',
    features: [
      'Página Inicial, Sobre, Serviços, Equipe e Contato',
      'Integração com Google Maps e WhatsApp',
      'Certificado de Segurança SSL incluso',
      'Formulário inteligente com envio instantâneo',
      'SEO básico para buscas no Google',
    ],
  },
  {
    id: 'ecommerce',
    title: 'Loja Virtual & E-commerce',
    tagline: 'Venda seus produtos 24 horas por dia',
    description:
      'Plataforma de vendas online rápida, segura e elegante. Mostre seus produtos com fotos em alta definição e receba pagamentos por Pix e cartão.',
    deliveryTime: '3 a 5 dias úteis',
    idealFor: 'Boutiques, semijoias, vestuário, cosméticos e comércio varejista',
    features: [
      'Catálogo de produtos com fotos em alta resolução',
      'Checkout descomplicado (Pix instantâneo e Cartão)',
      'Cálculo de frete automático (Correios/Melhor Envio)',
      'Notificações de pedidos no WhatsApp',
      'Painel intuitivo para você gerenciar o estoque',
    ],
  },
  {
    id: 'catalogo-digital',
    title: 'Cardápio & Catálogo Interativo',
    tagline: 'Vendas diretas no WhatsApp sem comissões',
    description:
      'Diga adeus às taxas abusivas de aplicativos de entrega. Seus clientes montam o pedido na tela e enviam o carrinho direto para o seu WhatsApp.',
    deliveryTime: 'Entrega no mesmo dia',
    idealFor: 'Restaurantes, bistrôs, confeitarias, lanchonetes e artesãos',
    features: [
      'Cardápio interativo e responsivo para celulares',
      'Fotos apetitosas e descrições detalhadas',
      'Montagem de carrinho e cálculo de subtotal',
      'Disparo de pedido formatado no WhatsApp',
      'QR Code de mesa para impressão física',
    ],
  },
];

export interface PortfolioProject {
  id: string;
  title: string;
  category: 'E-commerce' | 'Institucional' | 'Landing Page' | 'Gastronomia';
  clientName: string;
  segment: string;
  image: string;
  headline: string;
  description: string;
  deliverySpeed: string;
  metrics: {
    label: string;
    value: string;
  }[];
  tags: string[];
}

export const PORTFOLIO_PROJECTS: PortfolioProject[] = [
  {
    id: 'aurelia-luxury',
    title: 'Aurélia Joias & Alta Costura',
    category: 'E-commerce',
    clientName: 'Aurélia Atelier',
    segment: 'Joalheria & Acessórios Premium',
    image: '/src/assets/images/project_ecommerce_luxury_1793651053330.jpg',
    headline: 'E-commerce de luxo com aumento de 320% nas vendas online',
    description:
      'Desenvolvimento de experiência digital refinada para boutique de semijoias finas. Paleta escura com dourado metálico, fotografia imersiva e checkout direto que triplicou o ticket médio dos pedidos.',
    deliverySpeed: 'Entregue em 48h',
    metrics: [
      { label: 'Crescimento de Vendas', value: '+320%' },
      { label: 'Ticket Médio', value: 'R$ 680' },
      { label: 'Tempo de Carregamento', value: '1.1s' },
    ],
    tags: ['E-commerce', 'Checkout Pix', 'Design de Luxo', 'Responsivo'],
  },
  {
    id: 'lumina-aesthetics',
    title: 'Lumina Estética & Saúde Integrada',
    category: 'Institucional',
    clientName: 'Dra. Eleanor Vance & Equipe',
    segment: 'Clínica Médica & Dermatologia Estética',
    image: '/src/assets/images/project_medical_clinic_1793651054269.jpg',
    headline: 'Agendamentos lotados e autoridade clínica inquestionável',
    description:
      'Website institucional para clínica de alto padrão, integrando agendamento direto de consultas via WhatsApp, biografia de especialistas e apresentação de tratamentos com apelo estético impecável.',
    deliverySpeed: 'Entregue no mesmo dia (24h)',
    metrics: [
      { label: 'Contatos no WhatsApp', value: '+185%' },
      { label: 'Taxa de Agendamento', value: '42%' },
      { label: 'Nota no Google', value: '5.0' },
    ],
    tags: ['Institucional', 'Agendamento WhatsApp', 'Autoridade Médica', 'SEO Local'],
  },
  {
    id: 'noir-gastronomy',
    title: 'Noir & Gold Gastronomia',
    category: 'Gastronomia',
    clientName: 'Bistrô & Lounge Noir',
    segment: 'Alta Gastronomia & Coquetelaria',
    image: '/src/assets/images/project_gastronomy_restaurant_1793651054410.jpg',
    headline: 'Cardápio digital que gerou mais de 200 pedidos sem taxas',
    description:
      'Cardápio interativo e página de reservas para restaurante contemporâneo. Os clientes escaneiam o QR Code na mesa ou acessam pelo Instagram e pedem direto pelo WhatsApp da casa sem descontos de plataformas.',
    deliverySpeed: 'Entregue no mesmo dia (12h)',
    metrics: [
      { label: 'Economia em Taxas de App', value: 'R$ 8.400/mês' },
      { label: 'Pedidos WhatsApp', value: '+240/mês' },
      { label: 'Experiência do Cliente', value: '98% aprovação' },
    ],
    tags: ['Cardápio Digital', 'QR Code de Mesa', 'Reservas Online', 'Express'],
  },
];

export const TESTIMONIALS = [
  {
    id: '1',
    author: 'Ricardo Albuquerque',
    role: 'Diretor Geral',
    company: 'Clínica Revitalize (São Paulo, SP)',
    content:
      'Precisei de um site com urgência para abrir as vendas de um novo procedimento e a CA Creative entregou no mesmo dia! O visual preto e dourado trouxe uma presença de luxo incrível. No primeiro fim de semana o retorno foi mais de 10 vezes o valor do site.',
    rating: 5,
    highlight: 'Entregou no mesmo dia!',
  },
  {
    id: '2',
    author: 'Juliana Mendes',
    role: 'Proprietária & Designer',
    company: 'Atelier de Semijoias (Balneário Camboriú, SC)',
    content:
      'O atendimento pelo WhatsApp foi 100% humanizado, rápido e muito atencioso. Eles entenderam perfeitamente a essência da minha marca. Meus clientes elogiam a facilidade de navegar e meu faturamento dobrou!',
    rating: 5,
    highlight: 'Atendimento 100% humanizado',
  },
  {
    id: '3',
    author: 'Matheus Rezende',
    role: 'Sócio-Fundador',
    company: 'Bistrô Empório Gourmet (Curitiba, PR)',
    content:
      'Livramos nosso restaurante das taxas abusivas de aplicativos. Com o catálogo interativo da CA Creative, os clientes escolhem os pratos e o pedido chega pronto no nosso WhatsApp. Simplesmente sensacional!',
    rating: 5,
    highlight: 'Economia de milhares de reais',
  },
  {
    id: '4',
    author: 'Dra. Camila Vasconcelos',
    role: 'Advogada Sócia',
    company: 'Vasconcelos & Prado Advogados (Rio de Janeiro, RJ)',
    content:
      'A CA Creative transformou a nossa imagem profissional. Transmitimos a credibilidade e solidez que clientes corporativos exigem. Já fechamos contratos de 5 dígitos diretamente através de pessoas que nos acharam no site.',
    rating: 5,
    highlight: 'Máxima autoridade corporativa',
  },
];

export const FAQ_ITEMS = [
  {
    question: 'Como funciona a Entrega no Mesmo Dia?',
    answer:
      'Para projetos prioritários como Landing Pages e Cardápios Digitais, temos um fluxo Express. Se você nos enviar as informações essenciais pela manhã, nossa equipe inicia o desenvolvimento imediatamente e coloca seu site no ar no mesmo dia, sem perder nada em qualidade estética ou técnica.',
  },
  {
    question: 'Como é feito o atendimento?',
    answer:
      'O atendimento é 100% humanizado e direto pelo WhatsApp (47 99894-731). Você conversa com um especialista que entende de negócios e design, sem robôs automáticos chatos ou atendentes que não sabem resolver.',
  },
  {
    question: 'Não tenho textos nem fotos profissionais. Vocês ajudam?',
    answer:
      'Com certeza! Nossa equipe é especializada em copywriting persuasivo. Criamos textos estratégicos focados em convencer o seu cliente a comprar, além de selecionar e tratar imagens de altíssima definição para a sua marca.',
  },
  {
    question: 'Quais são as formas de pagamento disponíveis?',
    answer:
      'Trabalhamos com Pix à vista com desconto especial, ou parcelamento facilitado no cartão de crédito em até 12x. Você só dá início com um sinal e quitamos na entrega com o site aprovado.',
  },
  {
    question: 'O site funciona perfeitamente em celulares?',
    answer:
      'Sim, 100%! Desenvolvemos cada site no padrão Mobile-First, com botões de toque confortáveis, fontes legíveis e carregamento instantâneo no 4G e 5G.',
  },
  {
    question: 'Terei suporte após a entrega do site?',
    answer:
      'Sim! Não te deixamos na mão. Após colocar seu site no ar, oferecemos suporte técnico contínuo para garantir que tudo funcione com estabilidade, segurança e velocidade.',
  },
];
