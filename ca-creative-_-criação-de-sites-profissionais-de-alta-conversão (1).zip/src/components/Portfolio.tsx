import React, { useState } from 'react';
import { Eye, ExternalLink, Zap, MessageCircle, ArrowRight, X } from 'lucide-react';
import { PORTFOLIO_PROJECTS, PortfolioProject, buildWhatsAppLink } from '../data/content';

export const Portfolio: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedProject, setSelectedProject] = useState<PortfolioProject | null>(null);

  const categories = [
    { id: 'all', label: 'Todos os Projetos' },
    { id: 'E-commerce', label: 'E-commerce & Lojas' },
    { id: 'Institucional', label: 'Clínicas & Institucionais' },
    { id: 'Gastronomia', label: 'Restaurantes & Catálogos' },
  ];

  const filteredProjects =
    activeCategory === 'all'
      ? PORTFOLIO_PROJECTS
      : PORTFOLIO_PROJECTS.filter((p) => p.category === activeCategory);

  return (
    <section id="portfolio" className="py-24 bg-[#0c0c0e] relative border-t border-purple-950/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-12">
          <p className="text-xs uppercase tracking-widest text-purple-400 font-semibold mb-3">
            Casos de Sucesso & Resultados
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight mb-5" style={{ textWrap: 'balance' }}>
            Projetos Criados para{' '}
            <span className="purple-gradient-text font-serif italic">Dominar o Mercado</span>
          </h2>
          <p className="text-base text-zinc-400 leading-relaxed">
            Veja como transformamos negócios comuns em marcas digitais cobiçadas, com design moderno e impactante em roxo & preto, entregas recordes e foco em vendas.
          </p>
        </div>

        {/* Filter Tabs (Interactive Segmented Control, not pills) */}
        <div className="flex items-center justify-center mb-14">
          <div className="inline-flex p-1.5 rounded-xl bg-zinc-900 border border-zinc-800 max-w-full overflow-x-auto">
            {categories.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setActiveCategory(cat.id)}
                className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors whitespace-nowrap ${
                  activeCategory === cat.id
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-500/25'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Project Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          {filteredProjects.map((project) => {
            const projectWhatsAppUrl = buildWhatsAppLink(
              `Olá! Vi o projeto "${project.title}" no portfólio da CA Creative e gostaria de criar algo semelhante para o meu negócio.`
            );

            return (
              <div
                key={project.id}
                className="group rounded-2xl bg-zinc-950 border border-zinc-800/90 hover:border-purple-500/50 transition-all duration-300 overflow-hidden flex flex-col justify-between hover:shadow-2xl hover:shadow-purple-500/10"
              >
                <div>
                  {/* Thumbnail Container */}
                  <div className="relative aspect-[4/3] overflow-hidden bg-zinc-900">
                    <img
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/20 to-transparent pointer-events-none" />

                    {/* Speed indicator */}
                    <div className="absolute top-4 right-4 px-3 py-1 rounded-md bg-zinc-950/90 backdrop-blur-md border border-purple-400/40 text-[11px] font-bold text-purple-300 flex items-center gap-1.5 shadow-lg">
                      <Zap className="w-3 h-3 text-purple-400" />
                      <span>{project.deliverySpeed}</span>
                    </div>

                    {/* Overlay Action Button on Hover */}
                    <button
                      type="button"
                      onClick={() => setSelectedProject(project)}
                      className="absolute inset-0 m-auto w-12 h-12 rounded-full bg-purple-600/90 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 shadow-2xl hover:bg-purple-500"
                      aria-label={`Ver detalhes de ${project.title}`}
                    >
                      <Eye className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Card Content */}
                  <div className="p-6 sm:p-7">
                    {/* Unboxed metadata line with bullet separators */}
                    <div className="flex items-center gap-2 text-xs text-zinc-500 mb-2">
                      <span>{project.segment}</span>
                      <span aria-hidden="true">·</span>
                      <span className="text-purple-400 font-medium">{project.category}</span>
                    </div>

                    <h3 className="text-xl font-bold text-white mb-2 group-hover:text-purple-300 transition-colors">
                      {project.title}
                    </h3>

                    <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed mb-6">
                      {project.headline}
                    </p>

                    {/* Metrics Strip */}
                    <div className="grid grid-cols-3 gap-2 py-3 px-3 rounded-xl bg-zinc-900/60 border border-zinc-800/80 mb-6 text-center">
                      {project.metrics.map((m, i) => (
                        <div key={i}>
                          <div className="text-xs sm:text-sm font-bold text-purple-300 tabular-nums">
                            {m.value}
                          </div>
                          <div className="text-[10px] text-zinc-400 leading-tight">
                            {m.label}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Footer Action */}
                <div className="px-6 pb-6 pt-0 flex items-center justify-between gap-3 border-t border-zinc-900/80 pt-4">
                  <button
                    type="button"
                    onClick={() => setSelectedProject(project)}
                    className="text-xs font-semibold text-zinc-300 hover:text-purple-300 flex items-center gap-1 transition-colors"
                  >
                    <span>Ver detalhes</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>

                  <a
                    href={projectWhatsAppUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-sm transition-all"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>Quero um Igual</span>
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Banner */}
        <div className="text-center">
          <p className="text-sm text-zinc-400 mb-4">
            Tem um nicho específico? Criamos para farmácias, escritórios de advocacia, construtoras, mecânicas, personal trainers e muito mais.
          </p>
          <a
            href={buildWhatsAppLink('Olá! Gostaria de ver mais exemplos de sites criados pela CA Creative para o meu segmento.')}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-sm font-bold text-purple-400 hover:text-purple-300 transition-colors"
          >
            <span>Solicitar exemplos específicos para o seu nicho no WhatsApp</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </div>

      {/* Case Details Modal */}
      {selectedProject && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200"
        >
          <div className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-2xl bg-zinc-950 border border-purple-500/40 p-6 sm:p-8 shadow-2xl text-left purple-glow">
            <button
              type="button"
              onClick={() => setSelectedProject(null)}
              className="absolute top-4 right-4 p-2 rounded-lg bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
              aria-label="Fechar detalhes"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="mb-6 rounded-xl overflow-hidden border border-zinc-800 aspect-[16/9] max-h-[340px]">
              <img
                src={selectedProject.image}
                alt={selectedProject.title}
                className="w-full h-full object-cover object-top"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="flex items-center gap-2 text-xs text-purple-400 font-semibold mb-2">
              <span>{selectedProject.category}</span>
              <span>·</span>
              <span>{selectedProject.deliverySpeed}</span>
            </div>

            <h3 className="text-2xl sm:text-3xl font-bold text-white mb-3">
              {selectedProject.title}
            </h3>

            <p className="text-base text-zinc-300 leading-relaxed mb-6">
              {selectedProject.description}
            </p>

            <div className="grid grid-cols-3 gap-4 p-4 rounded-xl bg-zinc-900/80 border border-zinc-800 mb-6 text-center">
              {selectedProject.metrics.map((m, i) => (
                <div key={i}>
                  <div className="text-lg sm:text-2xl font-bold text-purple-400 tabular-nums">
                    {m.value}
                  </div>
                  <div className="text-xs text-zinc-400">{m.label}</div>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap gap-2 mb-8">
              {selectedProject.tags.map((tag, i) => (
                <span
                  key={i}
                  className="px-3 py-1 rounded-md text-xs font-medium bg-zinc-900 border border-zinc-800 text-zinc-300"
                >
                  {tag}
                </span>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-end gap-3 pt-4 border-t border-zinc-800">
              <button
                type="button"
                onClick={() => setSelectedProject(null)}
                className="w-full sm:w-auto px-5 py-2.5 rounded-lg text-sm text-zinc-400 hover:text-white"
              >
                Voltar ao Portfólio
              </button>
              <a
                href={buildWhatsAppLink(
                  `Olá! Vi os detalhes do case "${selectedProject.title}" e quero um projeto desse nível para a minha empresa.`
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-lg text-sm font-bold text-white bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-600 hover:from-purple-500 shadow-md"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Quero um Site Como Este</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
