import React from 'react';
import { MessageCircle, ArrowRight, Zap, CheckCircle2, Star } from 'lucide-react';
import { CONTACT_INFO, buildWhatsAppLink } from '../data/content';

export const Hero: React.FC = () => {
  const whatsappHeroUrl = buildWhatsAppLink(
    'Olá! Vi a CA Creative e quero solicitar um orçamento para o site da minha empresa com entrega no mesmo dia.'
  );

  return (
    <section className="relative pt-32 pb-20 md:pt-40 md:pb-32 overflow-hidden bg-[#09090b] bg-grid-subtle">
      {/* Deep purple radial ambient glows */}
      <div
        className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[750px] h-[450px] bg-gradient-to-tr from-purple-600/20 via-violet-600/10 to-indigo-900/15 rounded-full blur-[140px] pointer-events-none"
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-4xl mx-auto">
          {/* Top Tagline / Opening Motto */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-950/40 border border-purple-500/40 text-xs sm:text-sm font-medium text-purple-300 mb-6 shadow-sm">
            <Zap className="w-4 h-4 text-purple-400 shrink-0" />
            <span className="tracking-wide">
              {CONTACT_INFO.tagline}
            </span>
          </div>

          {/* Main Headline */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white mb-6 leading-[1.15]" style={{ textWrap: 'balance' }}>
            Transforme visitantes em clientes com um site{' '}
            <span className="purple-gradient-text font-serif italic font-bold">
              moderno, veloz e persuasivo
            </span>
          </h1>

          {/* Subtitle / Value Prop */}
          <p className="text-base sm:text-xl text-zinc-300 mb-9 max-w-2xl mx-auto leading-relaxed font-normal">
            A <strong>CA Creative</strong> cria sites profissionais e personalizados para empresas e comércios que desejam mais visibilidade, credibilidade inquestionável e faturamento acelerado.
          </p>

          {/* Action CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
            <a
              href={whatsappHeroUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-4 rounded-xl text-base font-bold text-white bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-xl shadow-purple-500/25 hover:shadow-purple-500/40 transition-all duration-200 transform hover:-translate-y-0.5 active:translate-y-0"
            >
              <MessageCircle className="w-5 h-5 fill-white/20" />
              <span>Solicitar Orçamento no WhatsApp</span>
              <ArrowRight className="w-4 h-4" />
            </a>

            <a
              href="#portfolio"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-4 rounded-xl text-base font-semibold text-zinc-200 bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-700 hover:border-purple-400/50 transition-all duration-200"
            >
              <span>Ver Projetos Recentes</span>
            </a>
          </div>

          {/* Quick Trust Highlights */}
          <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-10 text-xs sm:text-sm text-zinc-400 pt-2 border-t border-zinc-800/80 max-w-3xl mx-auto">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0" />
              <span>⚡ Entrega no mesmo dia disponível</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0" />
              <span>🤝 Atendimento 100% humanizado</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0" />
              <span>📱 100% Mobile-First no 4G/5G</span>
            </div>
          </div>
        </div>

        {/* Visual Studio Showcase Frame (Focal Carrier) */}
        <div className="mt-14 relative mx-auto max-w-5xl">
          <div className="relative rounded-2xl p-1 bg-gradient-to-b from-purple-500/40 via-violet-900/20 to-zinc-900/40 shadow-2xl purple-glow">
            <div className="relative rounded-xl overflow-hidden bg-zinc-950 aspect-[16/9] border border-purple-900/30">
              <img
                src="/src/assets/images/hero_creative_workspace_1793651050797.jpg"
                alt="Ambiente de criação de sites profissionais da CA Creative com monitores de design e interfaces modernas"
                className="w-full h-full object-cover object-center transform hover:scale-[1.02] transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent pointer-events-none" />

              {/* In-image floating card */}
              <div className="absolute bottom-4 left-4 right-4 sm:bottom-6 sm:left-6 sm:right-auto max-w-md bg-zinc-950/92 backdrop-blur-md p-4 sm:p-5 rounded-xl border border-purple-500/40 shadow-2xl">
                <div className="flex items-center gap-2 mb-2 text-purple-300 text-xs font-semibold tracking-wider uppercase">
                  <Star className="w-3.5 h-3.5 fill-purple-400 text-purple-400" />
                  <span>Estúdio de Criação Digital</span>
                </div>
                <p className="text-xs sm:text-sm text-zinc-200 font-medium">
                  Da ideia à publicação em poucas horas: sites que convertem cliques em faturamento real para empresas do Brasil.
                </p>
                <div className="mt-3 flex items-center gap-3 text-xs text-zinc-400">
                  <span className="text-purple-300 font-bold tabular-nums">+150</span>
                  <span>projetos publicados</span>
                  <span>·</span>
                  <span className="text-zinc-300">Garantia total</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
