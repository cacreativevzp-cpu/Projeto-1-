import React from 'react';
import { MessageCircle, Instagram, ArrowUp, ShieldCheck } from 'lucide-react';
import { CONTACT_INFO, buildWhatsAppLink } from '../data/content';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const whatsappUrl = buildWhatsAppLink(
    'Olá! Gostaria de conversar com a CA Creative sobre a criação de um site.'
  );

  return (
    <footer className="bg-[#070708] border-t border-purple-950/40 text-zinc-400 text-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 mb-12">
          {/* Brand info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 via-violet-600 to-indigo-700 flex items-center justify-center text-white font-black text-sm shadow-md shadow-purple-500/20">
                CA
              </span>
              <span className="text-xl font-bold text-white tracking-wide">
                CA <span className="purple-gradient-text">Creative</span>
              </span>
              <span className="text-purple-400 text-xs">💜</span>
            </div>

            <p className="text-zinc-400 text-sm leading-relaxed max-w-sm">
              {CONTACT_INFO.tagline}
            </p>

            <p className="text-xs text-zinc-500 leading-relaxed">
              Especialistas em criação de sites profissionais, modernos e de alta conversão para empresas e comércios de todo o Brasil.
            </p>

            <div className="flex items-center gap-3 pt-2">
              <a
                href={CONTACT_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-white hover:border-purple-400/50 hover:bg-purple-500/10 transition-colors"
                aria-label="Instagram da CA Creative"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-white hover:border-purple-400/50 hover:bg-purple-500/10 transition-colors"
                aria-label="WhatsApp da CA Creative"
              >
                <MessageCircle className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4">
              Navegação
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm">
              <li>
                <a href="#diferenciais" className="hover:text-purple-300 transition-colors">
                  Diferenciais
                </a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-purple-300 transition-colors">
                  Serviços
                </a>
              </li>
              <li>
                <a href="#portfolio" className="hover:text-purple-300 transition-colors">
                  Portfólio & Cases
                </a>
              </li>
              <li>
                <a href="#sobre" className="hover:text-purple-300 transition-colors">
                  Sobre a CA Creative
                </a>
              </li>
              <li>
                <a href="#depoimentos" className="hover:text-purple-300 transition-colors">
                  Depoimentos
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-purple-300 transition-colors">
                  Dúvidas Frequentes
                </a>
              </li>
            </ul>
          </div>

          {/* Solutions */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4">
              Soluções
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm">
              <li>
                <a href="#servicos" className="hover:text-purple-300 transition-colors">
                  Landing Pages Express
                </a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-purple-300 transition-colors">
                  Sites Institucionais
                </a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-purple-300 transition-colors">
                  Lojas Virtuais & E-commerce
                </a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-purple-300 transition-colors">
                  Cardápios Digitais
                </a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-purple-300 transition-colors">
                  Redesign & Otimização
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Direct */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4">
              Contato Direto
            </h4>
            <div className="space-y-3 text-xs sm:text-sm">
              <div>
                <span className="text-zinc-500 block text-[11px]">WhatsApp</span>
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-white hover:text-purple-300 font-semibold"
                >
                  {CONTACT_INFO.whatsappDisplay}
                </a>
              </div>
              <div>
                <span className="text-zinc-500 block text-[11px]">Instagram</span>
                <a
                  href={CONTACT_INFO.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-white hover:text-purple-300 font-semibold"
                >
                  {CONTACT_INFO.instagramHandle}
                </a>
              </div>
              <div className="pt-2">
                <a
                  href="/cacreative-projeto.zip"
                  download="cacreative-projeto.zip"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-purple-300 bg-purple-950/40 border border-purple-500/40 hover:bg-purple-900/40 transition-colors"
                >
                  <span>📦 Baixar Código ZIP</span>
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom copyright line */}
        <div className="pt-8 border-t border-zinc-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-500">
          <p>
            © {new Date().getFullYear()} CA Creative. Todos os direitos reservados.
          </p>

          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1.5 text-zinc-400">
              <ShieldCheck className="w-4 h-4 text-purple-400" />
              <span>Garantia de Qualidade & Entrega no Mesmo Dia</span>
            </span>

            <button
              type="button"
              onClick={scrollToTop}
              className="p-2 rounded-lg bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
              aria-label="Voltar ao topo da página"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
