import React, { useState } from 'react';
import { Check, Clock, ArrowRight, MessageCircle, SlidersHorizontal } from 'lucide-react';
import { SERVICES, buildWhatsAppLink } from '../data/content';

export const Services: React.FC = () => {
  // Interactive Project Simulator State
  const [selectedService, setSelectedService] = useState<string>('landing-page');
  const [urgency, setUrgency] = useState<'same-day' | 'standard'>('same-day');
  const [includeCopy, setIncludeCopy] = useState<boolean>(true);
  const [includeSeo, setIncludeSeo] = useState<boolean>(true);
  const [includeMaintenance, setIncludeMaintenance] = useState<boolean>(false);

  const activeServiceObj = SERVICES.find((s) => s.id === selectedService) || SERVICES[0];

  const generateSimulatorWhatsAppLink = () => {
    const urgencyText = urgency === 'same-day' ? '⚡ Entrega no Mesmo Dia (Express)' : 'Padrão (3 a 5 dias úteis)';
    const extras: string[] = [];
    if (includeCopy) extras.push('Copywriting Persuasivo');
    if (includeSeo) extras.push('Otimização para o Google (SEO)');
    if (includeMaintenance) extras.push('Suporte & Manutenção Mensal');

    const msg = `Olá, CA Creative! Gostaria de um orçamento para o meu projeto:
- Tipo: ${activeServiceObj.title}
- Prazo desejado: ${urgencyText}
- Recursos: ${extras.length > 0 ? extras.join(', ') : 'Padrão'}

Como podemos dar início?`;

    return buildWhatsAppLink(msg);
  };

  return (
    <section id="servicos" className="py-24 bg-[#09090b] relative border-t border-purple-950/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <p className="text-xs uppercase tracking-widest text-purple-400 font-semibold mb-3">
            O Que Fazemos
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight mb-5" style={{ textWrap: 'balance' }}>
            Soluções Digitais sob Medida para{' '}
            <span className="purple-gradient-text font-serif italic">Multiplicar seu Faturamento</span>
          </h2>
          <p className="text-base text-zinc-400 leading-relaxed">
            Seja para lançar uma oferta urgente no mesmo dia ou construir a presença digital definitiva da sua empresa, temos o formato exato para seu momento de negócio.
          </p>
        </div>

        {/* Services Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-20">
          {SERVICES.map((service, index) => {
            const serviceWhatsAppUrl = buildWhatsAppLink(
              `Olá! Gostaria de solicitar um orçamento para o serviço "${service.title}" com a CA Creative.`
            );

            return (
              <div
                key={service.id}
                className={`relative rounded-2xl p-8 sm:p-10 transition-all duration-300 flex flex-col justify-between ${
                  service.recommended
                    ? 'bg-zinc-950 border-2 border-purple-500/80 shadow-2xl shadow-purple-500/10'
                    : 'bg-zinc-950/80 border border-zinc-800/90 hover:border-purple-500/40'
                }`}
              >
                {service.recommended && (
                  <div className="absolute -top-3.5 right-6 px-4 py-1 rounded-full bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-600 text-white font-bold text-xs uppercase tracking-wider shadow-md">
                    Mais Procurado
                  </div>
                )}

                <div>
                  <div className="text-xs font-semibold text-zinc-500 mb-2">
                    0{index + 1} · {service.tagline}
                  </div>

                  <h3 className="text-2xl font-bold text-white mb-3">
                    {service.title}
                  </h3>

                  <p className="text-sm text-zinc-400 mb-6 leading-relaxed">
                    {service.description}
                  </p>

                  <div className="flex items-center gap-2 text-xs font-medium text-purple-300 bg-purple-500/10 border border-purple-500/20 px-3.5 py-2 rounded-lg w-fit mb-6">
                    <Clock className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                    <span>Prazo: {service.deliveryTime}</span>
                  </div>

                  <div className="space-y-3 mb-8">
                    <p className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
                      O que está incluso:
                    </p>
                    {service.features.map((feat, i) => (
                      <div key={i} className="flex items-start gap-2.5 text-xs sm:text-sm text-zinc-300">
                        <Check className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-6 border-t border-zinc-900 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="text-xs text-zinc-500 text-center sm:text-left">
                    <span className="text-zinc-400">Ideal para:</span> {service.idealFor}
                  </div>
                  <a
                    href={serviceWhatsAppUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg text-xs font-bold text-white bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-md transition-all active:scale-95 whitespace-nowrap"
                  >
                    <span>Pedir Orçamento</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {/* Interactive Project Simulator Box */}
        <div className="rounded-2xl bg-zinc-950 border border-purple-500/40 p-6 sm:p-10 shadow-2xl relative overflow-hidden purple-glow">
          <div className="flex items-center gap-2 text-xs font-bold text-purple-400 uppercase tracking-widest mb-3">
            <SlidersHorizontal className="w-4 h-4 text-purple-400" />
            <span>Simulador de Orçamento Interativo</span>
          </div>

          <h3 className="text-2xl sm:text-3xl font-bold text-white mb-3">
            Monte a proposta perfeita para o seu negócio
          </h3>
          <p className="text-sm text-zinc-400 mb-8 max-w-2xl">
            Escolha o modelo de site e prazo desejado. Ao clicar no botão, geramos a mensagem formatada para você enviar direto no nosso WhatsApp sem burocracia.
          </p>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Controls */}
            <div className="lg:col-span-7 space-y-6">
              {/* Step 1: Select Type */}
              <div>
                <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-3">
                  1. Escolha o Tipo de Site
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {SERVICES.map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => setSelectedService(s.id)}
                      className={`text-left p-3.5 rounded-xl border text-xs sm:text-sm transition-all ${
                        selectedService === s.id
                          ? 'border-purple-400 bg-purple-500/15 text-white font-semibold'
                          : 'border-zinc-800 bg-zinc-900/50 text-zinc-400 hover:border-zinc-700'
                      }`}
                    >
                      <div className="font-bold text-white mb-0.5">{s.title}</div>
                      <div className="text-xs text-zinc-400">{s.tagline}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 2: Urgency */}
              <div>
                <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-3">
                  2. Prazo de Entrega Desejado
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setUrgency('same-day')}
                    className={`p-3.5 rounded-xl border text-xs sm:text-sm text-left transition-all ${
                      urgency === 'same-day'
                        ? 'border-purple-400 bg-purple-500/15 text-white font-semibold'
                        : 'border-zinc-800 bg-zinc-900/50 text-zinc-400 hover:border-zinc-700'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 font-bold text-purple-300 mb-0.5">
                      <span>⚡ Entrega no Mesmo Dia</span>
                    </div>
                    <div className="text-xs text-zinc-400">Sprint express em poucas horas</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setUrgency('standard')}
                    className={`p-3.5 rounded-xl border text-xs sm:text-sm text-left transition-all ${
                      urgency === 'standard'
                        ? 'border-purple-400 bg-purple-500/15 text-white font-semibold'
                        : 'border-zinc-800 bg-zinc-900/50 text-zinc-400 hover:border-zinc-700'
                    }`}
                  >
                    <div className="font-bold text-white mb-0.5">Padrão (3 a 5 dias úteis)</div>
                    <div className="text-xs text-zinc-400">Desenvolvimento com revisões</div>
                  </button>
                </div>
              </div>

              {/* Step 3: Add-ons */}
              <div>
                <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-3">
                  3. Recursos Complementares
                </label>
                <div className="flex flex-wrap gap-3">
                  <button
                    type="button"
                    onClick={() => setIncludeCopy(!includeCopy)}
                    className={`px-4 py-2 rounded-lg text-xs font-medium border transition-colors ${
                      includeCopy
                        ? 'bg-purple-600 text-white font-bold border-purple-500'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {includeCopy ? '✓ ' : '+ '} Copywriting Persuasivo
                  </button>

                  <button
                    type="button"
                    onClick={() => setIncludeSeo(!includeSeo)}
                    className={`px-4 py-2 rounded-lg text-xs font-medium border transition-colors ${
                      includeSeo
                        ? 'bg-purple-600 text-white font-bold border-purple-500'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {includeSeo ? '✓ ' : '+ '} Otimização para Google (SEO)
                  </button>

                  <button
                    type="button"
                    onClick={() => setIncludeMaintenance(!includeMaintenance)}
                    className={`px-4 py-2 rounded-lg text-xs font-medium border transition-colors ${
                      includeMaintenance
                        ? 'bg-purple-600 text-white font-bold border-purple-500'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {includeMaintenance ? '✓ ' : '+ '} Suporte & Manutenção Mensal
                  </button>
                </div>
              </div>
            </div>

            {/* Summary Preview Box */}
            <div className="lg:col-span-5 bg-zinc-900/80 rounded-xl p-6 border border-zinc-800 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between text-xs text-purple-400 font-semibold uppercase tracking-wider mb-4 pb-3 border-b border-zinc-800">
                  <span>Resumo do Pedido</span>
                  <span>CA Creative</span>
                </div>

                <div className="space-y-3 mb-6 text-sm">
                  <div>
                    <span className="text-xs text-zinc-400">Modelo Selecionado:</span>
                    <p className="font-bold text-white">{activeServiceObj.title}</p>
                  </div>

                  <div>
                    <span className="text-xs text-zinc-400">Prazo Escolhido:</span>
                    <p className="font-semibold text-purple-300">
                      {urgency === 'same-day' ? '⚡ Entrega no Mesmo Dia (Express)' : 'Padrão (3 a 5 dias úteis)'}
                    </p>
                  </div>

                  <div>
                    <span className="text-xs text-zinc-400">Atendimento:</span>
                    <p className="text-zinc-200">100% Humanizado via WhatsApp</p>
                  </div>

                  <div>
                    <span className="text-xs text-zinc-400">Garantia:</span>
                    <p className="text-zinc-200">Revisão até aprovação e suporte pós-entrega</p>
                  </div>
                </div>
              </div>

              <div>
                <a
                  href={generateSimulatorWhatsAppLink()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full inline-flex items-center justify-center gap-2 px-6 py-4 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-xl shadow-purple-500/25 transition-all active:scale-95 text-center"
                >
                  <MessageCircle className="w-5 h-5 fill-white/20" />
                  <span>Pedir Proposta Personalizada no WhatsApp</span>
                </a>
                <p className="text-center text-xs text-zinc-500 mt-2">
                  Você será atendido em minutos por nossa equipe de criação.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
