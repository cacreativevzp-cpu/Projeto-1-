import React, { useState } from 'react';
import { MessageCircle, Send, Instagram, Phone, MapPin, CheckCircle2, Zap } from 'lucide-react';
import { CONTACT_INFO, buildWhatsAppLink } from '../data/content';

export const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    company: '',
    serviceType: 'Landing Page Express (Entrega no mesmo dia)',
    urgency: 'Urgente - Quero no mesmo dia!',
    notes: '',
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const formattedMessage = `Olá, CA Creative! Gostaria de um orçamento para o meu site:
- *Nome:* ${formData.name}
- *Empresa / Nicho:* ${formData.company || 'Não informado'}
- *WhatsApp de Contato:* ${formData.phone}
- *Tipo de Site:* ${formData.serviceType}
- *Prazo Desejado:* ${formData.urgency}
${formData.notes ? `- *Detalhes:* ${formData.notes}` : ''}

Aguardo o retorno para darmos início!`;

    const waLink = buildWhatsAppLink(formattedMessage);
    setSubmitted(true);
    window.open(waLink, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="contato" className="py-24 bg-[#09090b] relative border-t border-purple-950/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Left Column: Direct Info & Social */}
          <div className="lg:col-span-5 space-y-8">
            <div>
              <p className="text-xs uppercase tracking-widest text-purple-400 font-semibold mb-3">
                Contato Direto
              </p>
              <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight mb-4" style={{ textWrap: 'balance' }}>
                Pronto para ter um site que{' '}
                <span className="purple-gradient-text font-serif italic">vende de verdade?</span>
              </h2>
              <p className="text-base text-zinc-300 leading-relaxed">
                Preencha o formulário ou fale conosco diretamente pelo WhatsApp. Nosso atendimento é 100% humanizado e sem enrolação.
              </p>
            </div>

            {/* Direct Contact Cards */}
            <div className="space-y-4">
              <a
                href={buildWhatsAppLink('Olá, CA Creative! Gostaria de conversar diretamente pelo WhatsApp.')}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-start gap-4 p-5 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-purple-400/50 transition-colors"
              >
                <div className="w-12 h-12 rounded-lg bg-purple-500/10 border border-purple-400/20 flex items-center justify-center text-purple-400 shrink-0 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-zinc-400 font-medium">WhatsApp Oficial</div>
                  <div className="text-lg font-bold text-white group-hover:text-purple-300 transition-colors">
                    {CONTACT_INFO.whatsappDisplay}
                  </div>
                  <div className="text-xs text-purple-400 mt-1 flex items-center gap-1 font-medium">
                    <Zap className="w-3 h-3" />
                    <span>Clique para chamar agora · Resposta rápida</span>
                  </div>
                </div>
              </a>

              <a
                href={CONTACT_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-start gap-4 p-5 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-purple-400/50 transition-colors"
              >
                <div className="w-12 h-12 rounded-lg bg-purple-500/10 border border-purple-400/20 flex items-center justify-center text-purple-400 shrink-0 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                  <Instagram className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-zinc-400 font-medium">Instagram Oficial</div>
                  <div className="text-lg font-bold text-white group-hover:text-purple-300 transition-colors">
                    {CONTACT_INFO.instagramHandle}
                  </div>
                  <div className="text-xs text-zinc-400 mt-1">
                    Dicas de design, bastidores e cases reais
                  </div>
                </div>
              </a>

              <div className="flex items-start gap-4 p-5 rounded-xl bg-zinc-950 border border-zinc-800">
                <div className="w-12 h-12 rounded-lg bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-zinc-400 font-medium">Área de Atendimento</div>
                  <div className="text-base font-semibold text-white">
                    {CONTACT_INFO.region}
                  </div>
                  <div className="text-xs text-zinc-400 mt-1">
                    Atendemos empresas, clínicas e comércios de ponta a ponta do país
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: High-Conversion Form */}
          <div className="lg:col-span-7">
            <div className="rounded-2xl bg-zinc-950 border border-purple-500/30 p-8 sm:p-10 shadow-2xl relative purple-glow">
              <div className="flex items-center justify-between mb-6 pb-4 border-b border-zinc-800">
                <h3 className="text-xl sm:text-2xl font-bold text-white">
                  Solicitar Orçamento Personalizado
                </h3>
                <span className="text-xs font-semibold px-3 py-1 rounded-full bg-purple-950/50 border border-purple-500/30 text-purple-300">
                  ⚡ Entrega no Mesmo Dia
                </span>
              </div>

              {submitted ? (
                <div className="py-12 text-center space-y-4 animate-in fade-in duration-300">
                  <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto mb-2">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h4 className="text-2xl font-bold text-white">
                    Mensagem Preparada com Sucesso!
                  </h4>
                  <p className="text-sm text-zinc-300 max-w-md mx-auto leading-relaxed">
                    Sua solicitação foi enviada para o nosso WhatsApp. Caso a conversa não tenha aberto automaticamente, clique no botão abaixo para falar conosco agora:
                  </p>
                  <div className="pt-4 flex flex-col sm:flex-row justify-center gap-3">
                    <a
                      href={buildWhatsAppLink(
                        `Olá! Enviei a solicitação pelo site para a empresa ${formData.company || formData.name}.`
                      )}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-600 hover:from-purple-500 shadow-lg shadow-purple-500/25"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>Abrir WhatsApp Novamente</span>
                    </a>
                    <button
                      type="button"
                      onClick={() => setSubmitted(false)}
                      className="px-5 py-3 rounded-xl text-sm font-semibold text-zinc-400 hover:text-white bg-zinc-900 border border-zinc-800"
                    >
                      Preencher Outra Proposta
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                        Seu Nome *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="Ex: Carlos Eduardo"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-800 text-white placeholder-zinc-500 focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 text-sm"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                        Seu WhatsApp com DDD *
                      </label>
                      <input
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="(DDD) 99999-9999"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-800 text-white placeholder-zinc-500 focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 text-sm"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                      Nome da Empresa ou Nicho de Atuação
                    </label>
                    <input
                      type="text"
                      value={formData.company}
                      onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                      placeholder="Ex: Clínica Odontológica, Loja de Roupas, Advocacia..."
                      className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-800 text-white placeholder-zinc-500 focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 text-sm"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                        Qual tipo de site você precisa?
                      </label>
                      <select
                        value={formData.serviceType}
                        onChange={(e) => setFormData({ ...formData, serviceType: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-800 text-white focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 text-sm"
                      >
                        <option value="Landing Page Express (Entrega no mesmo dia)">
                          Landing Page Express (Mesmo Dia)
                        </option>
                        <option value="Site Institucional Completo">
                          Site Institucional Completo
                        </option>
                        <option value="Loja Virtual & E-commerce">
                          Loja Virtual & E-commerce
                        </option>
                        <option value="Cardápio / Catálogo Interativo no WhatsApp">
                          Cardápio / Catálogo Digital
                        </option>
                        <option value="Redesign de Site Antigo">
                          Redesign / Modernização de Site
                        </option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                        Qual a sua urgência?
                      </label>
                      <select
                        value={formData.urgency}
                        onChange={(e) => setFormData({ ...formData, urgency: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-800 text-white focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 text-sm"
                      >
                        <option value="⚡ Urgente - Quero no mesmo dia!">
                          ⚡ Urgente - Quero no mesmo dia!
                        </option>
                        <option value="Nos próximos 2 a 3 dias">
                          Nos próximos 2 a 3 dias
                        </option>
                        <option value="Esta semana">
                          Esta semana
                        </option>
                        <option value="Apenas pesquisando valores">
                          Apenas pesquisando valores
                        </option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                      Conte um pouco mais sobre o seu projeto (Opcional)
                    </label>
                    <textarea
                      rows={3}
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      placeholder="Ex: Já tenho Instagram, preciso de botões para o WhatsApp e quero destacar meus principais serviços..."
                      className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-800 text-white placeholder-zinc-500 focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 text-sm"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full inline-flex items-center justify-center gap-3 px-8 py-4 rounded-xl text-base font-bold text-white bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-xl shadow-purple-500/25 transition-all active:scale-[0.99] cursor-pointer"
                  >
                    <MessageCircle className="w-5 h-5 fill-white/20" />
                    <span>Enviar e Solicitar Orçamento no WhatsApp</span>
                  </button>

                  <p className="text-center text-xs text-zinc-500">
                    Seus dados estão 100% seguros. Direcionamos você diretamente ao WhatsApp oficial da CA Creative.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
