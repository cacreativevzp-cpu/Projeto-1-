import React, { useState } from 'react';
import { ChevronDown, MessageCircle } from 'lucide-react';
import { FAQ_ITEMS, buildWhatsAppLink } from '../data/content';

export const Faq: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleAccordion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const whatsappFaqUrl = buildWhatsAppLink(
    'Olá, CA Creative! Tenho uma dúvida sobre a criação de sites e gostaria de tirar no WhatsApp.'
  );

  return (
    <section id="faq" className="py-24 bg-[#0c0c0e] relative border-t border-purple-950/40">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <p className="text-xs uppercase tracking-widest text-purple-400 font-semibold mb-3">
            Tire Suas Dúvidas
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight mb-4" style={{ textWrap: 'balance' }}>
            Perguntas Frequentes sobre a{' '}
            <span className="purple-gradient-text font-serif italic">Criação do seu Site</span>
          </h2>
          <p className="text-base text-zinc-400">
            Tudo o que você precisa saber para dar o próximo passo com total segurança e transparência.
          </p>
        </div>

        {/* Accordion List */}
        <div className="space-y-4 mb-14">
          {FAQ_ITEMS.map((item, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={index}
                className="rounded-xl bg-zinc-950 border border-zinc-800/80 overflow-hidden transition-colors"
              >
                <button
                  type="button"
                  onClick={() => toggleAccordion(index)}
                  className="w-full p-6 text-left flex items-center justify-between gap-4 focus:outline-none focus-visible:ring-2 focus-visible:ring-purple-400"
                  aria-expanded={isOpen}
                >
                  <span className="text-base sm:text-lg font-semibold text-white">
                    {item.question}
                  </span>
                  <ChevronDown
                    className={`w-5 h-5 text-purple-400 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'transform rotate-180' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-6 pb-6 pt-1 text-sm sm:text-base text-zinc-300 leading-relaxed border-t border-zinc-900 animate-in fade-in duration-200">
                    {item.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Still have questions card */}
        <div className="p-6 sm:p-8 rounded-2xl bg-zinc-900/60 border border-zinc-800 text-center flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-center sm:text-left">
            <h4 className="text-base font-bold text-white mb-1">
              Ficou alguma dúvida específica sobre seu nicho?
            </h4>
            <p className="text-xs sm:text-sm text-zinc-400">
              Nossa equipe responde em poucos minutos no WhatsApp com atendimento 100% humanizado.
            </p>
          </div>
          <a
            href={whatsappFaqUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="shrink-0 inline-flex items-center gap-2 px-5 py-2.5 rounded-lg text-xs sm:text-sm font-semibold text-white bg-purple-600 hover:bg-purple-500 shadow-md shadow-purple-500/25 transition-colors whitespace-nowrap"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Tirar Dúvida no WhatsApp</span>
          </a>
        </div>
      </div>
    </section>
  );
};
