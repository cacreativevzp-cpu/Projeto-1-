import React, { useState, useEffect } from 'react';
import { MessageCircle, Menu, X, ArrowUpRight, Download } from 'lucide-react';
import { CONTACT_INFO, buildWhatsAppLink } from '../data/content';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const defaultWhatsAppUrl = buildWhatsAppLink(
    'Olá, CA Creative! Gostaria de solicitar um orçamento para o site da minha empresa.'
  );

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#09090b]/92 backdrop-blur-md border-b border-purple-900/30 shadow-2xl shadow-purple-950/20'
          : 'bg-transparent border-b border-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-20">
          {/* Zone 1: Brand wordmark */}
          <a
            href="#"
            className="flex items-center gap-2 text-xl font-bold tracking-tight text-white whitespace-nowrap shrink-0 group"
          >
            <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 via-violet-600 to-indigo-700 flex items-center justify-center text-white font-black text-sm shadow-md shadow-purple-500/30 group-hover:scale-105 transition-transform">
              CA
            </span>
            <span className="font-semibold text-white tracking-wide">
              CA <span className="purple-gradient-text font-bold">Creative</span>
            </span>
            <span className="text-purple-400 text-xs font-normal" title="Transformando ideias em soluções">
              💜
            </span>
          </a>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-zinc-300">
            <a
              href="#diferenciais"
              className="hover:text-purple-300 transition-colors whitespace-nowrap shrink-0 py-1"
            >
              Diferenciais
            </a>
            <a
              href="#servicos"
              className="hover:text-purple-300 transition-colors whitespace-nowrap shrink-0 py-1"
            >
              Serviços
            </a>
            <a
              href="#portfolio"
              className="hover:text-purple-300 transition-colors whitespace-nowrap shrink-0 py-1"
            >
              Portfólio
            </a>
            <a
              href="#sobre"
              className="hover:text-purple-300 transition-colors whitespace-nowrap shrink-0 py-1"
            >
              Sobre
            </a>
            <a
              href="#depoimentos"
              className="hover:text-purple-300 transition-colors whitespace-nowrap shrink-0 py-1"
            >
              Depoimentos
            </a>
            <a
              href="#contato"
              className="hover:text-purple-300 transition-colors whitespace-nowrap shrink-0 py-1"
            >
              Contato
            </a>
          </nav>

          {/* Zone 3: Actions */}
          <div className="hidden sm:flex items-center gap-3 shrink-0">
            {/* Direct ZIP download button for Lovable / Netlify */}
            <a
              href="/cacreative-projeto.zip"
              download="cacreative-projeto.zip"
              className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-lg text-xs font-semibold text-zinc-300 hover:text-white bg-zinc-900/80 hover:bg-zinc-800 border border-purple-500/30 transition-all hover:border-purple-400/60 whitespace-nowrap"
              title="Baixar arquivo ZIP do projeto para Lovable ou Netlify"
            >
              <Download className="w-4 h-4 text-purple-400" />
              <span>Baixar ZIP</span>
            </a>

            {/* Primary Action Button */}
            <a
              href={defaultWhatsAppUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs md:text-sm font-semibold text-white bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-md shadow-purple-500/25 hover:shadow-purple-500/40 transition-all duration-200 active:scale-95 whitespace-nowrap"
            >
              <MessageCircle className="w-4 h-4 fill-white/20" />
              <span>Orçamento no WhatsApp</span>
            </a>
          </div>

          {/* Mobile hamburger button */}
          <div className="flex md:hidden items-center gap-2">
            <a
              href="/cacreative-projeto.zip"
              download="cacreative-projeto.zip"
              aria-label="Baixar ZIP do projeto"
              className="p-2 rounded-lg bg-zinc-900 border border-purple-500/40 text-purple-300 hover:text-white"
            >
              <Download className="w-5 h-5" />
            </a>
            <a
              href={defaultWhatsAppUrl}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="WhatsApp"
              className="p-2 rounded-lg bg-purple-600 text-white hover:bg-purple-500 transition-colors"
            >
              <MessageCircle className="w-5 h-5" />
            </a>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800/60 focus:outline-none focus-visible:ring-2 focus-visible:ring-purple-400"
              aria-label="Abrir menu principal"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0c0c0e] border-b border-purple-900/40 px-6 py-6 space-y-4 shadow-2xl animate-in fade-in slide-in-from-top-4 duration-200">
          <nav className="flex flex-col space-y-3">
            <a
              href="#diferenciais"
              onClick={() => setMobileMenuOpen(false)}
              className="text-base font-medium text-zinc-300 hover:text-purple-300 py-2 border-b border-zinc-900"
            >
              Diferenciais
            </a>
            <a
              href="#servicos"
              onClick={() => setMobileMenuOpen(false)}
              className="text-base font-medium text-zinc-300 hover:text-purple-300 py-2 border-b border-zinc-900"
            >
              Serviços
            </a>
            <a
              href="#portfolio"
              onClick={() => setMobileMenuOpen(false)}
              className="text-base font-medium text-zinc-300 hover:text-purple-300 py-2 border-b border-zinc-900"
            >
              Portfólio & Cases
            </a>
            <a
              href="#sobre"
              onClick={() => setMobileMenuOpen(false)}
              className="text-base font-medium text-zinc-300 hover:text-purple-300 py-2 border-b border-zinc-900"
            >
              Sobre a CA Creative
            </a>
            <a
              href="#depoimentos"
              onClick={() => setMobileMenuOpen(false)}
              className="text-base font-medium text-zinc-300 hover:text-purple-300 py-2 border-b border-zinc-900"
            >
              Depoimentos de Clientes
            </a>
            <a
              href="#faq"
              onClick={() => setMobileMenuOpen(false)}
              className="text-base font-medium text-zinc-300 hover:text-purple-300 py-2 border-b border-zinc-900"
            >
              Dúvidas Frequentes
            </a>
          </nav>
          <div className="pt-2 space-y-2">
            <a
              href="/cacreative-projeto.zip"
              download="cacreative-projeto.zip"
              className="w-full flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold text-zinc-200 bg-zinc-900 border border-purple-500/40"
            >
              <Download className="w-4 h-4 text-purple-400" />
              <span>Baixar ZIP do Projeto (Netlify / Lovable)</span>
            </a>
            <a
              href={defaultWhatsAppUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setMobileMenuOpen(false)}
              className="w-full flex items-center justify-center gap-2 px-5 py-3 rounded-lg text-sm font-semibold text-white bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-600 shadow-lg shadow-purple-500/25"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Falar no WhatsApp ({CONTACT_INFO.whatsappDisplay})</span>
              <ArrowUpRight className="w-4 h-4 ml-auto" />
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
