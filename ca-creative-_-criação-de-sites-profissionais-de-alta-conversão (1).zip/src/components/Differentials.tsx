import React from 'react';
import { Zap, HeartHandshake, TrendingUp, Smartphone, Sparkles, CheckSquare, ArrowRight } from 'lucide-react';
import { DIFFERENTIALS, buildWhatsAppLink } from '../data/content';

const iconMap: Record<string, React.ReactNode> = {
  'express-delivery': <Zap className="w-6 h-6 text-purple-400" />,
  'human-care': <HeartHandshake className="w-6 h-6 text-purple-400" />,
  'conversion-focus': <TrendingUp className="w-6 h-6 text-purple-400" />,
  'mobile-first': <Smartphone className="w-6 h-6 text-purple-400" />,
  'premium-aesthetic': <Sparkles className="w-6 h-6 text-purple-400" />,
  'turnkey-ready': <CheckSquare className="w-6 h-6 text-purple-400" />,
};

export const Differentials: React.FC = () => {
  const whatsappUrl = buildWhatsAppLink(
    'Olá! Quero um site com entrega no mesmo dia e atendimento humanizado. Poderiam me passar os detalhes?'
  );

  return (
    <section id="diferenciais" className="py-24 bg-[#09090b] relative border-t border-purple-950/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <p className="text-xs uppercase tracking-widest text-purple-400 font-semibold mb-3">
            Por Que Escolher a CA Creative
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight mb-5" style={{ textWrap: 'balance' }}>
            Diferenciais que colocam sua empresa{' '}
            <span className="purple-gradient-text font-serif italic">à frente da concorrência</span>
          </h2>
          <p className="text-base text-zinc-400 leading-relaxed">
            Eliminamos a lentidão e a burocracia das agências tradicionais. Nosso processo foi desenhado para quem precisa de agilidade comercial, qualidade visual e resultado direto nas vendas.
          </p>
        </div>

        {/* 6-Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {DIFFERENTIALS.map((item, index) => (
            <div
              key={item.id}
              className="group relative p-8 rounded-2xl bg-zinc-950/70 border border-zinc-800/90 hover:border-purple-400/50 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/10 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="w-12 h-12 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center group-hover:border-purple-500/40 group-hover:bg-purple-500/10 transition-colors">
                    {iconMap[item.id] || <Sparkles className="w-6 h-6 text-purple-400" />}
                  </div>
                  <span className="text-xs font-semibold px-3 py-1 rounded-full bg-purple-950/40 border border-purple-500/30 text-purple-300">
                    {item.badge}
                  </span>
                </div>

                <div className="text-xs font-medium text-zinc-500 mb-1 uppercase tracking-wider">
                  0{index + 1}. {item.subtitle}
                </div>

                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-purple-200 transition-colors">
                  {item.title}
                </h3>

                <p className="text-sm text-zinc-400 leading-relaxed font-normal">
                  {item.description}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-zinc-900 flex items-center text-xs font-medium text-purple-400/90 group-hover:text-purple-300 transition-colors">
                <span>Vantagem inclusa no seu projeto</span>
              </div>
            </div>
          ))}
        </div>

        {/* Speed Callout Banner */}
        <div className="p-8 sm:p-10 rounded-2xl bg-gradient-to-r from-zinc-950 via-purple-950/20 to-zinc-950 border border-purple-500/40 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl purple-glow">
          <div className="max-w-2xl text-center md:text-left">
            <div className="inline-flex items-center gap-2 text-purple-400 text-xs font-bold uppercase tracking-wider mb-2">
              <Zap className="w-4 h-4 fill-purple-400" />
              <span>Sprint Express Ativa Hoje</span>
            </div>
            <h4 className="text-2xl font-bold text-white mb-2">
              Precisa do seu site no ar ainda hoje?
            </h4>
            <p className="text-sm text-zinc-300 leading-relaxed">
              Inicie seu atendimento agora no WhatsApp. Analisamos seu nicho na hora e montamos sua estrutura no mesmo dia.
            </p>
          </div>
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="shrink-0 inline-flex items-center gap-2 px-6 py-3.5 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-lg shadow-purple-500/25 transition-all whitespace-nowrap active:scale-95"
          >
            <span>Garantir Vaga no Mesmo Dia</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  );
};
