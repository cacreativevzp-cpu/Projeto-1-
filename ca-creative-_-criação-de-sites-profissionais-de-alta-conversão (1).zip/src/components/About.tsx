import React from 'react';
import { Shield, Target, Eye, Instagram, MessageCircle, CheckCircle, ArrowRight } from 'lucide-react';
import { CONTACT_INFO, buildWhatsAppLink } from '../data/content';

export const About: React.FC = () => {
  const whatsappUrl = buildWhatsAppLink(
    'Olá! Li sobre a história e valores da CA Creative e quero conversar sobre o site da minha empresa.'
  );

  return (
    <section id="sobre" className="py-24 bg-[#0c0c0e] relative border-t border-purple-950/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Visual Brand Card */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl p-1 bg-gradient-to-tr from-purple-500/40 via-violet-900/20 to-indigo-900/30 shadow-2xl purple-glow">
              <div className="rounded-xl bg-zinc-950 p-8 sm:p-10 border border-zinc-800/90 relative overflow-hidden">
                {/* Subtle background monogram */}
                <div
                  className="absolute -right-8 -bottom-8 text-9xl font-black text-purple-950/30 select-none pointer-events-none"
                  aria-hidden="true"
                >
                  CA
                </div>

                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 via-violet-600 to-indigo-700 flex items-center justify-center text-white font-black text-lg shadow-md shadow-purple-500/30">
                    CA
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white tracking-wide">
                      CA Creative
                    </h3>
                    <p className="text-xs text-purple-300 font-medium">
                      Estúdio de Soluções Digitais
                    </p>
                  </div>
                </div>

                {/* Direct Prompt Quote */}
                <blockquote className="text-base text-zinc-300 leading-relaxed italic mb-8 font-serif">
                  &ldquo;A CA Creative é especializada na criação de sites profissionais, modernos e personalizados para empresas, comércios e estabelecimentos que desejam fortalecer sua presença digital, conquistar mais visibilidade, transmitir credibilidade e atrair novos clientes. Transformamos ideias em soluções digitais para levar seu negócio a outro nível! 💜&rdquo;
                </blockquote>

                <div className="space-y-3 pt-6 border-t border-zinc-800/80 text-sm">
                  <div className="flex items-center gap-3 text-zinc-300">
                    <CheckCircle className="w-4 h-4 text-purple-400 shrink-0" />
                    <span>Atendimento humanizado em todo o Brasil</span>
                  </div>
                  <div className="flex items-center gap-3 text-zinc-300">
                    <CheckCircle className="w-4 h-4 text-purple-400 shrink-0" />
                    <span>Metodologia ágil com entrega no mesmo dia</span>
                  </div>
                  <div className="flex items-center gap-3 text-zinc-300">
                    <CheckCircle className="w-4 h-4 text-purple-400 shrink-0" />
                    <span>Foco obsessivo em conversão e faturamento</span>
                  </div>
                </div>

                <div className="mt-8 pt-6 border-t border-zinc-800/80 flex items-center justify-between">
                  <a
                    href={CONTACT_INFO.instagramUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-xs font-semibold text-zinc-400 hover:text-purple-300 transition-colors"
                  >
                    <Instagram className="w-4 h-4" />
                    <span>{CONTACT_INFO.instagramHandle}</span>
                  </a>

                  <span className="text-xs text-purple-400 font-medium flex items-center gap-1">
                    <span>Brasil</span> 💜
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Mission, Vision & Pillars */}
          <div className="lg:col-span-7 space-y-8">
            <div>
              <p className="text-xs uppercase tracking-widest text-purple-400 font-semibold mb-3">
                Quem Somos & Nosso Propósito
              </p>
              <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight leading-tight mb-4" style={{ textWrap: 'balance' }}>
                Construímos ferramentas de vendas que{' '}
                <span className="purple-gradient-text font-serif italic">trabalham 24 horas por dia</span> para sua empresa
              </h2>
              <p className="text-base text-zinc-300 leading-relaxed">
                No cenário competitivo de hoje, não basta estar na internet: é preciso ser encontrado e transmitir confiança inabalável logo nos primeiros segundos.
              </p>
            </div>

            {/* 3 Pillars */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              <div className="p-5 rounded-xl bg-zinc-950/60 border border-zinc-800/80">
                <div className="w-10 h-10 rounded-lg bg-purple-500/10 border border-purple-400/20 flex items-center justify-center text-purple-400 mb-3">
                  <Eye className="w-5 h-5" />
                </div>
                <h4 className="text-base font-bold text-white mb-1">Visibilidade</h4>
                <p className="text-xs text-zinc-400 leading-relaxed">
                  Fazemos o mundo encontrar seu negócio através de posicionamento no Google e redes sociais.
                </p>
              </div>

              <div className="p-5 rounded-xl bg-zinc-950/60 border border-zinc-800/80">
                <div className="w-10 h-10 rounded-lg bg-purple-500/10 border border-purple-400/20 flex items-center justify-center text-purple-400 mb-3">
                  <Shield className="w-5 h-5" />
                </div>
                <h4 className="text-base font-bold text-white mb-1">Credibilidade</h4>
                <p className="text-xs text-zinc-400 leading-relaxed">
                  Visual moderno e sofisticado em roxo & preto que afasta a sensação de amadorismo e eleva seu preço.
                </p>
              </div>

              <div className="p-5 rounded-xl bg-zinc-950/60 border border-zinc-800/80">
                <div className="w-10 h-10 rounded-lg bg-purple-500/10 border border-purple-400/20 flex items-center justify-center text-purple-400 mb-3">
                  <Target className="w-5 h-5" />
                </div>
                <h4 className="text-base font-bold text-white mb-1">Novos Clientes</h4>
                <p className="text-xs text-zinc-400 leading-relaxed">
                  Textos persuasivos e botões diretos para transformar cada visitante em contato no WhatsApp.
                </p>
              </div>
            </div>

            {/* Direct CTA */}
            <div className="pt-2 flex flex-col sm:flex-row items-center gap-4">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-lg shadow-purple-500/25 transition-all active:scale-95"
              >
                <MessageCircle className="w-4 h-4 fill-white/20" />
                <span>Conversar com a Equipe no WhatsApp</span>
                <ArrowRight className="w-4 h-4" />
              </a>

              <span className="text-xs text-zinc-500 text-center sm:text-left">
                Resposta rápida em poucos minutos · Sem compromisso
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
