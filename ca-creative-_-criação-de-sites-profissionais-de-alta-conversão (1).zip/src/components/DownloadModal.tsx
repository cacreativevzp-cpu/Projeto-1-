import React, { useState } from 'react';
import { Download, X, CheckCircle2, ExternalLink, Sparkles, FolderArchive } from 'lucide-react';

export const DownloadModal: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const directCodeZipUrl = `${window.location.origin}/cacreative-codigo-completo.zip`;
  const directDistZipUrl = `${window.location.origin}/cacreative-dist-pronto-netlify.zip`;

  const copyUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  return (
    <>
      {/* Floating Bottom Bar for Quick Download */}
      <div className="fixed bottom-5 left-5 z-40 max-w-[calc(100vw-6rem)] sm:max-w-md">
        <button
          type="button"
          onClick={() => setIsOpen(true)}
          className="group flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-zinc-950/95 border border-purple-500/50 hover:border-purple-400 text-white shadow-2xl shadow-purple-950/40 text-xs sm:text-sm font-semibold transition-all hover:scale-105 active:scale-95"
          title="Baixar arquivos ZIP para Netlify ou Lovable"
        >
          <span className="w-2 h-2 rounded-full bg-purple-400" />
          <Download className="w-4 h-4 text-purple-400" />
          <span>Baixar ZIP do Projeto</span>
          <span className="hidden sm:inline-block text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-purple-500/20 text-purple-300">
            Netlify & Lovable
          </span>
        </button>
      </div>

      {/* Download Modal */}
      {isOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200"
        >
          <div className="relative w-full max-w-xl rounded-2xl bg-zinc-950 border border-purple-500/50 p-6 sm:p-8 shadow-2xl text-left purple-glow">
            {/* Close button */}
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-lg bg-zinc-900 text-zinc-400 hover:text-white transition-colors"
              aria-label="Fechar"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-xs font-bold text-purple-400 uppercase tracking-widest mb-2">
              <FolderArchive className="w-4 h-4" />
              <span>Arquivos Prontos para Hospedar</span>
            </div>

            <h3 className="text-xl sm:text-2xl font-bold text-white mb-2">
              Baixe os Arquivos do seu Projeto
            </h3>
            <p className="text-xs sm:text-sm text-zinc-400 mb-6">
              Preparamos duas versões para facilitar a sua publicação no Netlify ou no Lovable:
            </p>

            <div className="space-y-4 mb-6">
              {/* Option 1: Netlify pre-built dist */}
              <div className="p-4 rounded-xl bg-purple-950/20 border border-purple-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 text-sm font-bold text-white mb-1">
                    <span>1. Versão para Netlify (Já Compilada)</span>
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-semibold">
                      Mais Fácil
                    </span>
                  </div>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    Basta baixar, extrair e arrastar para o <strong>Netlify Drop</strong>. Não precisa rodar nenhum comando!
                  </p>
                </div>
                <a
                  href="/cacreative-dist-pronto-netlify.zip"
                  download="cacreative-dist-pronto-netlify.zip"
                  className="w-full sm:w-auto shrink-0 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 shadow-md whitespace-nowrap"
                >
                  <Download className="w-4 h-4" />
                  <span>Baixar ZIP Netlify</span>
                </a>
              </div>

              {/* Option 2: Full source code for Lovable */}
              <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 text-sm font-bold text-white mb-1">
                    <span>2. Código-Fonte Completo (Lovable / GitHub)</span>
                  </div>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    Contém todos os arquivos originais (React, TypeScript, Tailwind, imagens e configs) prontos para importar.
                  </p>
                </div>
                <a
                  href="/cacreative-codigo-completo.zip"
                  download="cacreative-codigo-completo.zip"
                  className="w-full sm:w-auto shrink-0 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold text-zinc-200 bg-zinc-800 hover:bg-zinc-700 hover:text-white border border-zinc-700 whitespace-nowrap"
                >
                  <Download className="w-4 h-4" />
                  <span>Baixar Código Fonte</span>
                </a>
              </div>
            </div>

            {/* Direct links to Netlify and Lovable */}
            <div className="pt-4 border-t border-zinc-800/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-zinc-400">
              <a
                href="https://app.netlify.com/drop"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 hover:text-purple-300 transition-colors"
              >
                <span>Acessar Netlify Drop</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <button
                type="button"
                onClick={() => copyUrl(directDistZipUrl)}
                className="hover:text-purple-300 transition-colors"
              >
                {copiedLink ? '✓ Link copiado para a área de transferência!' : 'Copiar link direto de download'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
