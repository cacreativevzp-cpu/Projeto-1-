import React from 'react';
import { Star, Quote, MessageCircle } from 'lucide-react';
import { TESTIMONIALS, buildWhatsAppLink } from '../data/content';

export const Testimonials: React.FC = () => {
  const whatsappUrl = buildWhatsAppLink(
    'Olá! Vi os depoimentos de clientes da CA Creative e quero solicitar um orçamento para o meu negócio.'
  );

  return (
    <section id="depoimentos" className="py-24 bg-[#09090b] relative border-t border-purple-950/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <p className="text-xs uppercase tracking-widest text-purple-400 font-semibold mb-3">
            Prova Social & Avaliações
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight mb-5" style={{ textWrap: 'balance' }}>
            O Que Nossos Clientes Dizem Sobre a{' '}
            <span className="purple-gradient-text font-serif italic">Velocidade & Atendimento</span>
          </h2>
          <p className="text-base text-zinc-400 leading-relaxed">
            Empresários de diversos segmentos que precisavam de agilidade, credibilidade e aumento real no faturamento.
          </p>
        </div>

        {/* Quant Proof Metrics Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 p-6 sm:p-8 rounded-2xl bg-zinc-950 border border-zinc-800/80 mb-16 text-center">
          <div>
            <div className="text-2xl sm:text-4xl font-black text-purple-400 tabular-nums mb-1">
              +150
            </div>
            <div className="text-xs sm:text-sm text-zinc-400">
              Sites Entregues no Brasil
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-4xl font-black text-purple-400 tabular-nums mb-1">
              100%
            </div>
            <div className="text-xs sm:text-sm text-zinc-400">
              No Prazo Acordado
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-4xl font-black text-purple-400 tabular-nums mb-1">
              4.9/5.0
            </div>
            <div className="text-xs sm:text-sm text-zinc-400">
              Avaliação Média dos Clientes
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-4xl font-black text-purple-400 tabular-nums mb-1">
              ⚡ Mesmo Dia
            </div>
            <div className="text-xs sm:text-sm text-zinc-400">
              Entrega Express Disponível
            </div>
          </div>
        </div>

        {/* Testimonials Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.id}
              className="p-8 sm:p-9 rounded-2xl bg-zinc-950/70 border border-zinc-800/80 hover:border-purple-400/40 transition-colors flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-1">
                    {[...Array(t.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-purple-400 text-purple-400" />
                    ))}
                  </div>
                  <span className="text-xs font-semibold px-2.5 py-1 rounded bg-purple-500/10 border border-purple-500/20 text-purple-300">
                    {t.highlight}
                  </span>
                </div>

                <p className="text-zinc-300 text-sm sm:text-base leading-relaxed italic mb-6">
                  &ldquo;{t.content}&rdquo;
                </p>
              </div>

              <div className="pt-4 border-t border-zinc-900 flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-white">{t.author}</h4>
                  <p className="text-xs text-zinc-400">{t.role} · {t.company}</p>
                </div>
                <div className="w-8 h-8 rounded-full bg-zinc-900 flex items-center justify-center text-purple-400">
                  <Quote className="w-4 h-4" />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Strip */}
        <div className="text-center">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-4 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-600 hover:from-purple-500 shadow-xl shadow-purple-500/20 transition-all active:scale-95"
          >
            <MessageCircle className="w-4 h-4 fill-white/20" />
            <span>Fazer Como Eles: Solicitar Orçamento no WhatsApp</span>
          </a>
        </div>
      </div>
    </section>
  );
};
