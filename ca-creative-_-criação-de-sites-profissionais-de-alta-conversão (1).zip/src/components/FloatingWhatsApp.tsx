import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { CONTACT_INFO, buildWhatsAppLink } from '../data/content';

export const FloatingWhatsApp: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(true);

  const whatsappUrl = buildWhatsAppLink(
    'Olá, CA Creative! Gostaria de falar com um especialista sobre o site da minha empresa.'
  );

  return (
    <div className="fixed bottom-5 right-5 z-40 flex flex-col items-end">
      {/* Speech bubble card */}
      {showTooltip && (
        <div className="mb-3 max-w-xs bg-zinc-950 border border-purple-400/40 rounded-2xl p-4 shadow-2xl shadow-purple-950/40 relative animate-in fade-in slide-in-from-bottom-2 duration-300 purple-glow">
          <button
            type="button"
            onClick={() => setShowTooltip(false)}
            className="absolute top-2 right-2 text-zinc-500 hover:text-white p-1"
            aria-label="Fechar mensagem"
          >
            <X className="w-3.5 h-3.5" />
          </button>

          <div className="flex items-center gap-2 mb-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span className="text-[11px] font-bold text-purple-300 uppercase tracking-wider">
              Atendimento Online Agora
            </span>
          </div>

          <p className="text-xs text-zinc-200 leading-snug mb-3 font-medium">
            Olá! Quer receber seu orçamento com entrega no mesmo dia? 💜
          </p>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-1.5 w-full py-2 px-3 rounded-lg text-xs font-bold text-white bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-600 hover:from-purple-500 shadow-md shadow-purple-500/25"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>Chamar no WhatsApp</span>
          </a>
        </div>
      )}

      {/* Main floating button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="group relative flex items-center justify-center w-14 h-14 rounded-full bg-gradient-to-tr from-purple-600 via-violet-600 to-emerald-500 text-white shadow-2xl hover:scale-105 active:scale-95 transition-all duration-300 focus:outline-none focus-visible:ring-4 focus-visible:ring-purple-400/50"
        aria-label="Falar com a CA Creative no WhatsApp"
      >
        {/* Glow */}
        <span className="absolute inset-0 rounded-full bg-purple-500/30 blur-md group-hover:blur-lg transition-all" />

        <MessageCircle className="w-7 h-7 relative z-10 fill-white" />
      </a>
    </div>
  );
};
